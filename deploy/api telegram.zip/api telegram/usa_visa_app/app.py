from flask import Flask, request, jsonify, render_template
import pandas as pd
import numpy as np
import pickle
from sklearn.preprocessing import StandardScaler

# Flask uygulaması oluşturma
app = Flask(__name__)

# Modeli yükle
model_dosyasi = "best_random_forest_model.pkl"
with open(model_dosyasi, "rb") as dosya:
    model = pickle.load(dosya)

# CSV dosyasının doğru dizinde olduğundan emin olun
csv_dosya = "C:/Users/bbatu/OneDrive/Masaüstü/api telegram/usa_visa.csv"  # Dizin yolunu buraya doğru yaz

try:
    veriler = pd.read_csv(csv_dosya)
    print("CSV dosyası başarıyla yüklendi!")
except FileNotFoundError:
    print(f"CSV dosyası yüklenirken hata oluştu: '{csv_dosya}' bulunamadı.")

# Ana sayfa route'u
@app.route("/")
def home():
    return "Model Başarıyla Yüklendi ve Çalışıyor!"

# API Route'u - Tahmin yapmak için
@app.route("/tahmin", methods=["POST"])
def tahmin():
    try:
        # İstekten JSON verisini al
        girdi_verileri = request.json

        # Verileri DataFrame'e dönüştür
        girdi_df = pd.DataFrame([girdi_verileri])

        # Model için uygun özellikleri seç
        X = girdi_df[['Saat_Sadece', 'Gün', 'Ay', 'Yıl', 'Dakika', 'Weekday', 'Month', 'Day']]

        # Tahmin yap
        tahmin_sonucu = model.predict(X)[0]

        # Yanıtı JSON formatında döndür
        return jsonify({"Tahmin Edilen Hour_Block": int(tahmin_sonucu)})

    except Exception as e:
        return jsonify({"hata": str(e)})

# Flask uygulamasını çalıştır
if __name__ == "__main__":
    app.run(debug=True)

@app.route("/tahmin", methods=["GET", "POST"])
def tahmin():
    if request.method == "GET":
        return "Bu sayfa sadece POST istekleri için kullanılabilir."
    try:
        # İstekten JSON verisini al
        girdi_verileri = request.json

        # Verileri DataFrame'e dönüştür
        girdi_df = pd.DataFrame([girdi_verileri])

        # Model için uygun özellikleri seç
        X = girdi_df[['Saat_Sadece', 'Gün', 'Ay', 'Yıl', 'Dakika', 'Weekday', 'Month', 'Day']]

        # Tahmin yap
        tahmin_sonucu = model.predict(X)[0]

        # Yanıtı JSON formatında döndür
        return jsonify({"Tahmin Edilen Hour_Block": int(tahmin_sonucu)})

    except Exception as e:
        return jsonify({"hata": str(e)})
